Inventory Management Module - .NET 8 MVC

1. Open the InventoryManagement folder in Visual Studio or VS Code.
2. Restore NuGet packages.
3. Run the project using dotnet run.
4. The app creates inventory.db and the Products table automatically on first run.
5. Browse to the local URL shown in the terminal.

Database provider: SQLite (Microsoft.Data.Sqlite), as used in the supplied PDF.
Views expect the normal MVC shared layout and _ValidationScriptsPartial from a standard MVC template.
